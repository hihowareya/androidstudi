package com.example.dominickwood.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Advanced extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_advanced);
    }

    public void advance2(View view)
    {
        Intent intent = new Intent(this, advance2.class);
        startActivity(intent);
    }

    public void sidePlank(View view)
    {
        Intent intent = new Intent(this, SidePlank.class);
        startActivity(intent);
    }

    public void wallStand(View view)
    {
        Intent intent = new Intent(this, WallStand.class);
        startActivity(intent);
    }

    public void wallArm(View view)
    {
        Intent intent = new Intent(this, WallArm.class);
        startActivity(intent);
    }

    public void crow(View view)
    {
        Intent intent = new Intent(this, Crow.class);
        startActivity(intent);
    }

    public void wheel(View view)
    {
        Intent intent = new Intent(this, Wheel.class);
        startActivity(intent);
    }
}
