package com.example.dominickwood.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class advance2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_advance2);
    }

    public void Advanced (View view)
    {
        Intent intent = new Intent(this, Advanced.class);
        startActivity(intent);
    }
}
