package com.example.dominickwood.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class advance2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_advance2);
    }

    public void Advanced (View view)
    {
        Intent intent = new Intent(this, Advanced.class);
        startActivity(intent);
    }

    public void seatfold(View view)
    {
        Intent intent = new Intent(this, seatfold.class);
        startActivity(intent);
    }

    public void revtriang(View view)
    {
        Intent intent = new Intent(this, revTrian.class);
        startActivity(intent);
    }

    public void boat(View view)
    {
        Intent intent = new Intent(this, Boat.class);
        startActivity(intent);
    }

    public void Headstand(View view)
    {
        Intent intent = new Intent(this, HeadStan.class);
        startActivity(intent);
    }

    public void Shouldstand(View view)
    {
        Intent intent = new Intent(this, ShouldS.class);
        startActivity(intent);
    }
}
