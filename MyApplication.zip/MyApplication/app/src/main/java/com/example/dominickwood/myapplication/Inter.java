package com.example.dominickwood.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Inter extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inter);
    }

    public void inter2(View view)
    {
        Intent intent = new Intent(this, inter2.class);
        startActivity(intent);
    }

    public void plank(View view)
    {
        Intent intent = new Intent(this, plank.class);
        startActivity(intent);
    }

    public void ChatDan(View view)
    {
        Intent intent = new Intent(this, ChatDan.class);
        startActivity(intent);
    }

    public void UpDog(View view)
    {
        Intent intent = new Intent(this, UpDog.class);
        startActivity(intent);
    }

    public void halfMoon(View view)
    {
        Intent intent = new Intent(this, HalfMoon.class);
        startActivity(intent);
    }

    public void Warr1(View view)
    {
        Intent intent = new Intent(this, Warr1.class);
        startActivity(intent);
    }
}
