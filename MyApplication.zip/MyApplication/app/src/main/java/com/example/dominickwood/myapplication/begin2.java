package com.example.dominickwood.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class begin2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_begin2);
    }

    public void Beginner (View view)
    {
        Intent intent = new Intent(this, Beginner.class);
        startActivity(intent);
    }

    public void triangle(View view)
    {
        Intent intent = new Intent(this, triangle.class);
        startActivity(intent);
    }

    public void tree(View view)
    {
        Intent intent = new Intent(this, tree.class);
        startActivity(intent);
    }

    public void bridge(View view)
    {
        Intent intent = new Intent(this, bridge.class);
        startActivity(intent);
    }

    public void bound(View view)
    {
        Intent intent = new Intent(this, bound.class);
        startActivity(intent);
    }

    public void corpse(View view)
    {
        Intent intent = new Intent(this, corpse.class);
        startActivity(intent);
    }
}
