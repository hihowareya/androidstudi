package com.example.dominickwood.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class inter2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inter2);
    }

    public void Inter (View view)
    {
        Intent intent = new Intent(this, Inter.class);
        startActivity(intent);
    }

    public void warr3(View view)
    {
        Intent intent = new Intent(this, warr3.class);
        startActivity(intent);
    }

    public void sideStr(View view)
    {
        Intent intent = new Intent(this, SideStr.class);
        startActivity(intent);
    }

    public void dolphin(View view)
    {
        Intent intent = new Intent(this, Dolphin.class);
        startActivity(intent);
    }

    public void Bow(View view)
    {
        Intent intent = new Intent(this, Bow.class);
        startActivity(intent);
    }

    public void Camel(View view)
    {
        Intent intent = new Intent(this, Camel.class);
        startActivity(intent);
    }
}
